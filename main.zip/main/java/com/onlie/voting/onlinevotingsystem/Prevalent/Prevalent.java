package com.onlie.voting.onlinevotingsystem.Prevalent;

import com.onlie.voting.onlinevotingsystem.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser;
}
